package com.example.mybluetooth;

import com.google.gson.annotations.SerializedName;

public class Post {
    @SerializedName("id")
    private int id;

    //ecg field
    @SerializedName("ecg")
    private String ecg;
    @SerializedName("ecg_user")
    private String ecg_user;
    @SerializedName("additional_data")
    private String additional_data;
    @SerializedName("created_date")
    private String created_date;

    //user field
    @SerializedName("email")
    private String email;
    @SerializedName("password")
    private String password;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    //ecg
    public String getEcg() {
        return ecg;
    }

    public void setEcg() { this.ecg = ecg; }

    public String getEcg_user() {
        return ecg_user;
    }

    public void setEcg_user() { this.ecg_user = ecg_user; }

    public String getAdditional_data() {
        return additional_data;
    }

    public void setAdditional_data() { this.additional_data = additional_data; }

    public String getCreated_date() {
        return created_date;
    }

    public void setCreated_date() { this.created_date = created_date; }


    //user
    public String getEmail() {
        return email;
    }

    public void setEmail() { this.email = email; }

    public String getPassword() { return password; }

    public void setPassword(){
        this.password = password;
    }
}